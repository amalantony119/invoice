This project is done in php codeigniter
please set the base url in "config.php" database cofiguration in "database.php" "in application/config"
"http://localhost/invoice/" base url
database file- "invoice.sql"