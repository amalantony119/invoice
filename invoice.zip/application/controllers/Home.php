<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	function __construct(){

        parent::__construct();

		$this->load->helper(array('form','url','string'));
		$this->load->model('Home_model');
		$this->load->library(array('session','form_validation'));
		
    }
       function index()
    {
            $data['result']= "";
            $data['active'] ="home";
            $data['invoices']=$this->Home_model->getinvoices();
            $this->load->view('home',$data);

    }
       function add_invoice()
    {
                $this->form_validation->set_rules('item1', 'Item Name', 'required',array('required' => 'Please Enter %s.'));
                $this->form_validation->set_rules('qty1', 'Quantity', 'required',array('required' => 'Please Enter %s.'));
                $this->form_validation->set_rules('price1', 'Unit Price', 'required',array('required' => 'Please Enter %s.'));
                $this->form_validation->set_rules('tax1', 'Tax', 'required',array('required' => 'Please Select %s.'));
                if($this->form_validation->run() == TRUE && isset($_POST['add_invoice']))
                {
                $dataorder=array( 'tax'=>0,
                    'discount'=>$this->input->post('discount'),
                    'grand_total'=>$this->input->post('subtotal'),
                    'created'=>date("Y-m-d")
                ); 
                $invoiceid=$this->Home_model->add_invoice($dataorder);
                if($invoiceid){
                $counter=$this->input->post('counter');
            	for($i=1;$i<=$counter;$i++){
                $tax=0;
                if($this->input->post('tax'.$i)==1) $tax=0;else if($this->input->post('tax'.$i)==2) $tax=1;else if($this->input->post('tax'.$i)==3) $tax=5;else if($this->input->post('tax'.$i)==4) $tax=10;
                $datas['order_id']		=	$invoiceid;
                $datas['product_name']		=	$this->input->post('item'.$i);
                $datas['quantity']		=	$this->input->post('qty'.$i);
                $datas['price']		=	$this->input->post('price'.$i);
                $datas['tax']		=	$tax;
                $datas['sub_total']		=	$this->input->post('twt'.$i);
                $this->Home_model->add_invoice_items($datas);
            	}
                $this->session->set_flashdata('msg', 'Invoice Added Sucessfully'); 
                redirect('Home/invoice/'.$invoiceid);
                }
                }
                else{
                    $data['active'] ="home";
                
                    $data['result']="";
                    $this->load->view('addinvoice',$data);
                }
           // $this->load->view('addinvoice',$data);

    }
       function invoice($id)
    {
            $data['result']= "";
            $data['active'] ="home";
            $data['order']=$this->Home_model->getInvoice($id);
            $this->load->view('invoice',$data);

    }
    function getitemvalue($id)   
    {
    $data['id']=$id;
    $this->load->view('ajaxitem',$data);        
    } 
}
