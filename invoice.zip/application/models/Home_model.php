<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model {

	function __construct(){

        parent::__construct();

		$this->load->database();

    }
    function getinvoices()
    {
    $this->db->select('*');
    $this->db->from('orders');
    $this->db->where(array('status' =>1));
    $query = $this-> db-> get()->result_array();
    return $query;	
    }
    function add_invoice($data)
    {
    $this->db->insert("orders",$data);
    $insert_id = $this->db->insert_id();
    return  $insert_id;    
    }
    function add_invoice_items($data)
    {
    $this->db->insert("order_items",$data);
    $insert_id = $this->db->insert_id();
    return  $insert_id;    
    }
    public function getInvoice($id){
        $this->db->select('o.*');
        $this->db->from('orders as o');
        $this->db->where('o.order_id', $id);
        $query = $this->db->get();
        $result = $query->row_array();
        
        // Get order items
        $this->db->select('i.*');
        $this->db->from('order_items as i');
       // $this->db->join('products as p', 'p.id = i.product_id', 'left');
        $this->db->where('i.order_id', $id);
        $query2 = $this->db->get();
        $result['items'] = ($query2->num_rows() > 0)?$query2->result_array():array();
        
        // Return fetched data
        return !empty($result)?$result:false;
        }      
}