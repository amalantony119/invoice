<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Invoices </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="robots" content="index, follow"/>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<script language="JavaScript" src="https://code.jquery.com/jquery-1.12.4.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css" />
</head>
<body>


    <div class="container">
        <div class="row">
            <h2 class="text-center">Invoice List</h2>
        </div>

        <div class="row">
            <div class="col-md-12" >
                <a class="btn btn-primary" style="margin:10px 0 10px " href="<?php echo base_url();?>Home/add_invoice/">Add New</a>

            </div>
            <div class="col-md-12">

                <table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Invoice ID</th>
                            <th>Total</th>
                            <th>Discount</th>
                            
                            <th>Sub Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($invoices)&&count($invoices)>0){
                        foreach ($invoices as $value) {?>
                        <tr>
                            <td><?php echo $value['order_id'];?></td>
                            <td><?php echo $value['grand_total']-($value['tax']+$value['discount']);?></td>
                            <td><?php echo $value['discount'];?></td>
                           
                            <td><?php echo $value['grand_total'];?></td>
                            <td>  <a href="<?php echo base_url();?>Home/invoice/<?php echo $value['order_id'];?>" class="btn btn-primary" style="margin:10px 0 10px ">Generate Invoice</a></td>
                        </tr>

                     <?php }}
                     else{?>
                     <tr>
                         <td colspan="5">No data</td>
                           
                        </tr>   
                     <?php }?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
<script>
  $(function () {
    $("#example").DataTable({
      "responsive": true,
      "autoWidth": false
    });

  });
 
</script>
</body>

</html>
