<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Invoices </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="robots" content="index, follow"/>
<meta name="keywords" content=""/>
<meta name="description" content=""/>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>

<div class="container">
    
    <div class="toolbar hidden-print" style="margin-top: 10px">
        <div class="text-right">
            <button id="printInvoice" class="btn btn-info"><i class="fa fa-print"></i> Print</button>
            <button class="btn btn-info"><a style="color:#fff" href="<?php echo base_url();?>home"><i class="fa fa-home"></i>Home </a></button>
        </div>
        <hr>
    </div>
    
    
    <div class="row" id="invoice">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="row p-5">
                        <div class="col-md-6">
                           
                        </div>

                        <div class="col-md-6 text-right">
                            <p class="font-weight-bold mb-1">Invoice #INV<?php echo $order['order_id']; ?></p>
<!--                            <p class="text-muted">Due to: 4 Dec, 2019</p>-->
                        </div>
                    </div>

                    <hr class="my-5">

             

                    <div class="row p-5">
                        <div class="col-md-12">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="border-0 text-uppercase small font-weight-bold">ID</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Item</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Quantity</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Unit Cost</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Tax(%)</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($order['items'])){$i=1; foreach($order['items'] as $item){ ?>
                                    <tr>
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $item['product_name']; ?></td>
                                        <td><?php echo $item['quantity']; ?></td>
                                        <td><?php echo "$".$item['price']; ?></td>
                                        <td><?php echo $item['tax']; ?></td>
                                        <td><?php echo "$".$item['sub_total']; ?></td>
                                    </tr>
                                     <?php $i++;}}?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="d-flex flex-row-reverse bg-dark text-white p-4">
                        <div class="py-3 px-5 text-right">
                            <div class="mb-2">Grand Total</div>
                            <div class="h2 font-weight-light"><?php echo "$".$order['grand_total'];?></div>
                        </div>

                        <div class="py-3 px-5 text-right">
                            <div class="mb-2">Discount</div>
                            <div class="h2 font-weight-light"><?php echo "$".$order['discount'];?></div>
                        </div>

                        <div class="py-3 px-5 text-right">
                            <div class="mb-2">Sub - Total amount</div>
                            <div class="h2 font-weight-light"><?php echo "$".($order['grand_total']+$order['discount']);?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
</div>
    <script>
  $('#printInvoice').click(function(){
 window.print();
                return true;
                });  
        </script>
</body>

</html>


