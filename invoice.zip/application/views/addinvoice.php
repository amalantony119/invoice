<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Invoices </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="robots" content="index, follow"/>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<script language="JavaScript" src="https://code.jquery.com/jquery-1.12.4.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css" />
</head>
<body>


    <div class="container">
        <div class="row">
            <h2 class="text-center">Add Invoice</h2>
        </div>

       
           
            <div class="col-md-12">

                <form method="post">
  <div class="form-row" id="item1row">
    <div class="col-md-2 mb-3">
      <label for="">Item Name</label>
      <input type="text" class="form-control" id="item1" name="item1" placeholder="Item Name" value="" required>
      <div class="valid-feedback">
       
      </div>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationServer02">Quantity</label>
      <input type="number" class="form-control" id="qty1" name="qty1" placeholder="Quantity" value="" required onchange="javascript:calculatetotal(1)">
      <div class="valid-feedback">
      
      </div>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Unit Price($)</label>
      <input type="number" class="form-control" id="price1" name="price1" placeholder="Unit Price" value="" required onchange="javascript:calculatetotal(1)">
      <div class="valid-feedback">
      
      </div>
    </div>
       <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Tax</label>
      <select class="form-control" id="tax1" name="tax1"  required style="height:34px" onchange="javascript:calculatetotal(1)">
          <option value="">Select</option>
          <option value="1">0%</option>
          <option value="2">1%</option>
          <option value="3">5%</option>
          <option value="4">10%</option>
      </select>
      <div class="valid-feedback">
      
      </div>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Total Without Tax($)</label>
      <input type="text" class="form-control" id="twot1" name="twot1" placeholder="Total Without Tax" value="0"  readonly="">
      <div class="valid-feedback">
      
      </div>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Total With Tax($)</label>
      <input type="text" class="form-control" id="twt1" name="twt1" placeholder="Total With Tax" value="0"  readonly="">
      <div class="valid-feedback">
      
      </div>
    </div>
    <div class="col-md-2 mb-3">
        <input type="hidden" value="1" id="counter" name="counter">
        <a onclick="addnew()"><i class="fa fa-plus"></i></a>
    </div>
  </div>
  <div class="form-row" >
 <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Total</label>
      <input type="text" class="form-control" id="total" name="total" placeholder="Total" value="0"  readonly="">
      <div class="valid-feedback">
      
      </div>
    </div>
      <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Discount</label>
      <input type="number" class="form-control" id="discount" name="discount" placeholder="Discount Amount" value="0" onchange="javascript:calculatediscount()">
      <div class="valid-feedback">
      
      </div>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Sub Total</label>
      <input type="number" class="form-control" id="subtotal" name="subtotal" placeholder="Subtotal" value="0"  readonly="">
      <div class="valid-feedback">
      
      </div>
    </div>
  </div>
  <div class="form-row" >
      <button class="btn btn-primary" type="submit" name="add_invoice">Submit</button>
  </div>
</form>

            </div>
        
    </div>
<script type="text/javascript">
function addnew()
{
      var counter=$('#counter').val();
      var val2 = parseInt(counter) + 1;    
     	 $.ajax({
		type: "POST",
                url: '<?php echo base_url();?>Home/getitemvalue/'+val2,
                success: function(data){  
		//  alert(data);exit;
	        $('div').find('#item'+counter+'row').after(data);
        document.getElementById("counter").value = val2;
					}
				 });
}
function remove()
{
      var counter=$('#counter').val();
       // alert(counter);
      var val2 = parseInt(counter) - 1; 
      jQuery('#item'+counter+'row').remove();
      document.getElementById("counter").value = val2;
}
function calculatetotal(id)
{
var total=0;var totalwt=0;var addedtotal=0;var addedtotalwt=0; 
var counter=$('#counter').val();
var price=$("#price"+id).val();    
var qty=$("#qty"+id).val();  
var tax=$("#tax"+id).val();
if(price!=''&&qty!=''){
var total=0;var totalwt=0;var addedtotal=0;var addedtotalwt=0; 
var twot= price*qty;   
document.getElementById("twot"+id).value = twot;
document.getElementById("twt"+id).value = twot;
for(var i=1;i<=counter;i++){
total=$("#twot"+i).val(); 
totalwt=$("#twt"+i).val(); 
addedtotal=parseFloat(total)+parseFloat(addedtotal);
addedtotalwt=parseFloat(totalwt)+parseFloat(addedtotalwt);
}
}
if(price!=''&&qty!=''&&tax!=''){
var total=0;var totalwt=0;var addedtotal=0;var addedtotalwt=0; 
if(tax==1) tax=0;else if(tax==2) tax=1;else if(tax==3) tax=5;else if(tax==4) tax=10;
var twot= parseFloat(price)*parseFloat(qty);   
var tax_amount= (tax/100)*twot; 
var twt=parseFloat(twot)+parseFloat(tax_amount);
document.getElementById("twt"+id).value = twt;
for(var i=1;i<=counter;i++){
total=$("#twot"+i).val(); 
totalwt=$("#twt"+i).val(); 
addedtotal=parseFloat(total)+parseFloat(addedtotal);
addedtotalwt=parseFloat(totalwt)+parseFloat(addedtotalwt);
}
}
document.getElementById("total").value =addedtotal;
var discount=$("#discount").val(); 
if(discount!=''){
var discounttotal=  parseFloat(addedtotalwt)-parseFloat(discount);  
document.getElementById("subtotal").value =discounttotal;
}
}
function calculatediscount()
{
var total=0;var totalwt=0;var addedtotal=0;var addedtotalwt=0; 
var counter=$('#counter').val();
for(var i=1;i<=counter;i++){
total=$("#twot"+i).val(); 
totalwt=$("#twt"+i).val(); 
addedtotal=parseFloat(total)+parseFloat(addedtotal);
addedtotalwt=parseFloat(totalwt)+parseFloat(addedtotalwt);
}
var discount=$("#discount").val(); 
if(discount!=''){
var discounttotal=  parseFloat(addedtotalwt)-parseFloat(discount);  
document.getElementById("subtotal").value =discounttotal;
}
}
</script>  
</body>

</html>
