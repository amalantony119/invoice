<div class="form-row" id="item<?php echo $id;?>row">
    <div class="col-md-2 mb-3">
      <label for="">Item Name</label>
      <input type="text" class="form-control" id="item<?php echo $id;?>" name="item<?php echo $id;?>" placeholder="Item Name" value="" required onchange="javascript:calculatetotal(<?php echo $id;?>)">
      <div class="valid-feedback">
       
      </div>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationServer02">Quantity</label>
      <input type="number" class="form-control" id="qty<?php echo $id;?>" name="qty<?php echo $id;?>" placeholder="Quantity" value="" required onchange="javascript:calculatetotal(<?php echo $id;?>)">
      <div class="valid-feedback">
      
      </div>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Unit Price($)</label>
      <input type="number" class="form-control" id="price<?php echo $id;?>" name="price<?php echo $id;?>" placeholder="Unit Price" value="" required onchange="javascript:calculatetotal(<?php echo $id;?>)">
      <div class="valid-feedback">
      
      </div>
    </div>
       <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Tax%</label>
      <select class="form-control" id="tax<?php echo $id;?>" name="tax<?php echo $id;?>"  required style="height:34px" onchange="javascript:calculatetotal(<?php echo $id;?>)">
          <option value="">Select</option>
          <option value="1">0%</option>
          <option value="2">1%</option>
          <option value="3">5%</option>
          <option value="4">10%</option>
      </select>
      <div class="valid-feedback">
      
      </div>
    </div>
         <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Total Without Tax($)</label>
      <input type="text" class="form-control" id="twot<?php echo $id;?>" name="twot<?php echo $id;?>" placeholder="Total Without Tax" value="0"  readonly="">
      <div class="valid-feedback">
      
      </div>
    </div>
         <div class="col-md-2 mb-3">
      <label for="validationServerUsername">Total With Tax($)</label>
      <input type="text" class="form-control" id="twt<?php echo $id;?>" name="twt<?php echo $id;?>" placeholder="Total With Tax" value="0"  readonly="">
      <div class="valid-feedback">
      
      </div>
    </div>
      <div class="col-md-2 mb-3">
      
        <a onclick="remove()"><i class="fa fa-minus"></i></a>
    </div>
  </div>